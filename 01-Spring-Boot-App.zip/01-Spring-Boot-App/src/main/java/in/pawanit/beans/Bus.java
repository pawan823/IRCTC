package in.pawanit.beans;

import org.springframework.stereotype.Component;

@Component
public class Bus {

	public Bus() {
		System.out.println("Bus::Constructor");
	}
	

}
