package in.pawanit.util;

public class DateUtil {
	public DateUtil() {
		System.out.println("DateUtil:: Constructor");
	}

}
