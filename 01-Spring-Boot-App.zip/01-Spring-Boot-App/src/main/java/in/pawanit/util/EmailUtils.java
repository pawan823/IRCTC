package in.pawanit.util;

import org.springframework.stereotype.Component;

@Component
public class EmailUtils {
	public  EmailUtils ()
	{
		System.out.println("EmailUtils:: Constructor");
		
	}

}
