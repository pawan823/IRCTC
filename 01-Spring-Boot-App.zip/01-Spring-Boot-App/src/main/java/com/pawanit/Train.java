package com.pawanit;

import org.springframework.stereotype.Component;

@Component
public class Train {
	
	public  Train()
	{
		System.out.println("Train:: Constructor");
	}
}
