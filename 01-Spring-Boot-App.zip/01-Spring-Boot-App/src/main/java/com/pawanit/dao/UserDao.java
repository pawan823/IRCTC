package com.pawanit.dao;

public class UserDao {

	public UserDao() {
		System.out.println("UserDao:: Constructor");
	}
	

}
