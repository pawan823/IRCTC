package coding.practice;

public class Program2 {

	public static void main(String[] args) {
		System.out.println((2+3)*4);

	}

}
