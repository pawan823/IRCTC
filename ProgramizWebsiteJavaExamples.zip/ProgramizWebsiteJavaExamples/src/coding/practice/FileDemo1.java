package coding.practice;

import java.io.File;
import java.io.IOException;

public class FileDemo1 {

	public static void main(String[] args)throws IOException {
		File f=new File("cheater.txt");
		System.out.println(f.exists());
		f.mkdir();
		System.out.println(f.exists());
		

	}

}
