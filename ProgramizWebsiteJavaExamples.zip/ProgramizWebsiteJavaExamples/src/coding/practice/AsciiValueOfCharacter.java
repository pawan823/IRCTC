package coding.practice;

public class AsciiValueOfCharacter {

	public static void main(String[] args) {
     char alphabet='A';
     char smallletter='a';
     int asciivalue=alphabet;
     int castingvalue=(int)alphabet;
     int smallcastingvalue=(int)smallletter;
     int smallasciivalue=smallletter;
     System.out.println(asciivalue);
     System.out.println(smallasciivalue);
     System.out.println(castingvalue);
     System.out.println(smallcastingvalue);
	}

}
