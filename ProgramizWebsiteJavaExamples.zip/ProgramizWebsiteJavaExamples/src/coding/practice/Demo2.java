package coding.practice;

public class Demo2
{
	public static void main(String[]args)
{
	System.out.println("hello");
	System.out.println("5");
	int n=100;
	System.out.println(n);
}
} 