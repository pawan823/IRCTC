/**
 * 
 */
package coding.practice;

import java.util.Scanner;

/**
 * @author pawan
 *
 */
public class PrintAnInteger {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
     System.out.println("Enter any Integer");
     Scanner sc=new Scanner(System.in);
     int number=sc.nextInt();

	
     System.out.println(number);
	}

}
