package coding.practice;

import java.io.File;
import java.io.IOException;

public class FileDemo5 {

	public static void main(String[] args) throws IOException{
		File f1=new File("Pawan");
		f1.mkdir();
		//File f2=new File("Pawan","Talent.txt");
		File f2=new File(f1,"Talent.txt");
		f2.createNewFile();
    
	}

}
