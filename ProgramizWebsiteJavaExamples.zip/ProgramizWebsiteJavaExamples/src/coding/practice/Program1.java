package coding.practice;

public class Program1 {

	public static void main(String[] args) {
    System.out.println(-6+4*2);
	}

}
