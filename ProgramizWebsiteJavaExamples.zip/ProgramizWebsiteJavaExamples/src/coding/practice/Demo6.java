package coding.practice;

public class Demo6 {
	static int b=10;

	public static void main(String[] args) {
	 	int a=2; //local variable
	 	System.out.println(b);

	}

}