package coding.practice;

public class Exercise {

	public static void main(String[] args) {
		
		int a=10;
		float f=10.5f;
		double d=20.123;
		System.out.println(a+f+d);
		method(a);
   
	}
	 public static void method(int a)
	 
	    {
	    	System.out.println(a);
	    }

}
