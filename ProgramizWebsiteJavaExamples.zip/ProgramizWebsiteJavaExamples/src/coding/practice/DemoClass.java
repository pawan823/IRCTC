package coding.practice;

public class DemoClass {

	public static void main(String[] args) {
    int a=5;
    double b=123.456;
    char c='P';
    String e = "hello";
    System.out.println(e);
	}

}
