package coding.practice;

public class Demo1 {

	public static void main(String[] args) {
		System.out.print("null");
		System.out.println("sample text2");
		System.out.println("sample text3");

	}

}
