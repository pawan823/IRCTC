package coding.practice;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

public class Property {

	public static void main(String[] args)throws Exception {
		Properties p=new Properties();
		FileInputStream fis=new FileInputStream("Pawan.txt");
		p.load(fis);
		
		System.out.println(p);
		String s=p.getProperty("venki");
		System.out.println("s");
		p.setProperty("Nag", "88888");
		FileOutputStream fos=new FileOutputStream("Pawan.txt");
		p.store(fos, "updated by pawan");
     
	}

}
