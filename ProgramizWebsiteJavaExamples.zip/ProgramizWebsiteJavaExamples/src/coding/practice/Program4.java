package coding.practice;

import java.util.Scanner;

public class Program4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter 1st no");
		int a=sc.nextInt();
		System.out.println("enter 1st no");
		int b=sc.nextInt();
		int c = (a+b);
		System.out.println("The sum of the two no is:" +c);
	}

}
