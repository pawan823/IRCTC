package coding.practice;

import java.util.Scanner;

public class AddTwoNo {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of A:");
		int A= sc.nextInt();
		
		System.out.println("Enter the value of B:");
		int B= sc.nextInt();
		int C=(A+B);
		System.out.println("Addition is:" + C);
		//2nd way
		int a,b,c;
		a=10;
		b=20;
		c=(a+b);
		System.out.println("addition is:"+c);
    
	}

}
