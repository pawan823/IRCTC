package coding.practice;

public class Program3 {

	public static void main(String[] args) {
		System.out.println(9+6-3*4/2%5);
	}

}
