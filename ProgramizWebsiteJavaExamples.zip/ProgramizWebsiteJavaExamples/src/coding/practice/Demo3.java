package coding.practice;

public class Demo3 
{

	public static void main(String[]args) 
	{
		if(args.length>0) {
			System.out.println("The below are the different args from command line");
		
			for(String value: args) {
				System.out.println(value  );
			}
		}
			else
			{
				System.out.println("no argument passed");
			}
		}
}
		
	


