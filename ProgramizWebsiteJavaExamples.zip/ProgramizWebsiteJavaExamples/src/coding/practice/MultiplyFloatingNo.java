package coding.practice;

public class MultiplyFloatingNo {

	public static void main(String[] args) {
     float f1=2.34f;
     float f2=3.3f;
     float f3=f1*f2;
     System.out.println(f3);
	}

}
